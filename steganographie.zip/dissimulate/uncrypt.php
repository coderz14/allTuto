<?php

 
 

// Fonction pour extraire le texte d'une image JPEG cachée
function extraireTexte($imagePath) {
    // Lire l'image

    $final_message = '';
 
$tampon = 0;
$message = "";
$i = 0; //variable qui va servir à compter le nombre d'octets déjà lus

$f_image = fopen($imagePath, 'rb'); // On ne modifie pas le fichier cette fois-ci, donc le mode r suffit.
fseek($f_image, 54); // On saute le header.
while(!feof($f_image)) // En théorie, on pourrait faire une boucle infinie que l'on ira « breaker » mais on ne va quand même pas tenter le diable, hein…

  {   $i++; //très important !

    $octet_image = fread($f_image, 1);
    $octet_image = ord($octet_image); // On lit la valeur du "charactère" lu.
    $bits_pf     = $octet_image%4;

    $tampon      = ($tampon << 2) | $bits_pf; // On rajoute ce qu'on a trouvé au tampon.

    if($i % 4 == 0) //c'est-à-dire quand on a lu 4 octets d'affilée
    {
        // Une fois qu'on a la valeur du caractère du message 
        

         // Une fois qu'on a la valeur du caractère du message 
        
        if($tampon == 26)
        {
            // Fin du message
            $final_message.= $message;
        
        }

        $message .= chr($tampon); // Si l'on n'est pas arrivé à la fin du message, on ajoute le caractère trouvé et on réinitialise le tampon.
        $tampon = 0;

       
    }
}



    return $final_message ;
}



?>




<!DOCTYPE html>
<html>
<head>
    <title>Bienvenu dans Coderz</title>

      <link rel="stylesheet" type="text/css" href="../public/css/modelcss/bootstrap.style.css">
</head>
<body>


<h1>Voir les infos dans l'image</h1>





<?php
 
if (isset($_POST['send']) AND isset($_POST['fichier']) ) {
    # code...


$data =  extraireTexte($_POST['fichier']);



?>

<div class="row">
    
<div class="col-lg-6 text-center" style="margin:auto;">
    
<h4 class="mt-5">
 <?php

 echo $data;

 ?>
 </h4>
</div>
 
    </div>



    <?php
}

else

{ 



?>

<div class="row  mt-5">

     <div class="col-lg-6">
    <style type="text/css">li{float:left;list-style-type: none;} a{margin-left: 20px; text-decoration: none; color: navy;} p{display: block;}</style>
    
    <ul>

        <li><a href="main.php">Acceuil</a></li>

        <li><a href="uncrypt.php">Voir les infos</a></li>
        
    </ul>
    </div>
</div> 

<div class="row  m-5">
    <div class="col-lg-6">
    <form method="post"   action="uncrypt.php">
        
<p>
    
 
 


         </p>

         <p>
Choississez votre image

<?php

foreach (glob("files_cript/*.*") as $fichier) {
    # code...

    echo "<p class='forme-inline'>". explode('/', $fichier)[1]."<img src='".$fichier."'  width='100' height='100'> <input type='radio' name='fichier' value='".$fichier."' value='form-contol'></p>";
}


?>
         
</p>

  <p class="forme-inline"><input type="submit" name="send" class="btn btn-success  w-3" value="Process" ></p>
           </form>
    
   </div>
</div> 


   <?php
}

 



?>
</body>
</html>