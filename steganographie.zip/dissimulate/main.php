 

<?php

// Fonction pour cacher un texte dans une image JPEG
function cacherTexteDansImage($imagePath, $message) {
    // Lire l'image
 $octet_decoupe = array();

$message .= chr(26);

// Là, ça commence à devenir intéressant.
$f_image = fopen($imagePath, 'r+b'); // On ouvre le fichier image, tout simplement.
fseek($f_image, 54); // On se place après le <italique>header</italique>.

for($i=0;$i<strlen($message);$i++)
{
        $caractere = $message[$i];
        $valeur_octet = ord($caractere);
    $octet_binaire = decbin($valeur_octet);

    $octet_binaire = str_pad($octet_binaire, 8, '0', STR_PAD_LEFT);

    $octet_decoupe = str_split($octet_binaire, 2);

    foreach($octet_decoupe AS $partie_octet)
    {
        
        $octet_image = fread($f_image, 1); // On récupère un seul octet, sous forme de caractère.
        $octet_image = ord($octet_image); // On le convertit en nombre grâce à la table ASCII.

        $octet_image -= $octet_image%4; // On rend les deux bits de poids faible égaux à zéro. La ligne suivante est équivalente mais utilise les opérateurs de bit.
        //$octet_image = $octet_image & 252;
        
        $partie_octet = bindec($partie_octet); // On reconvertit en base 10 pour pouvoir faire une addition.


        $octet_image += $partie_octet; // La deuxième étape

        fseek($f_image, -1, SEEK_CUR); // TRÈS IMPORTANT

        fputs($f_image, chr($octet_image)); // On écrit tout simplement dans le fichier, en écrasant l'octet suivant.
        
    }
}

fclose($f_image);
}

 

?>


 



<!DOCTYPE html>
<html>
<head>
    <title>Bienvenu dans Coderz</title>

      <link rel="stylesheet" type="text/css" href="../public/css/modelcss/bootstrap.style.css">
</head>
<body>


<h1>Coderz Stegano</h1>





<?php



if (isset($_POST['end']) AND  isset($_FILES['image'])) {
    # code...
$imageInfo = getimagesize($_FILES['image']['tmp_name']);

    
 

    if ($_FILES['image']['size'] < 5000000) {
        # code...
$nameFile = basename($_FILES['image']['name']);

             if (in_array(explode('/', $imageInfo['mime'])[1], array('bmp'))  AND !file_exists("files_cript/".$nameFile)) {
            # code...
//files_cript



$texte = $_POST['texte'] ;


            move_uploaded_file($_FILES['image']['tmp_name'], "files_cript/".$nameFile);


cacherTexteDansImage("files_cript/".$nameFile, $texte);

               echo "Les infos ont été renseignés avec succeés dans lefichier ".$nameFile." \n";
        }

        else {
            echo "Ce fichier existe deja";
        }

   
    }




?>



    <?php
}

else

{ 



?>

<div class="row  mt-5">

     <div class="col-lg-6">
    <style type="text/css">li{float:left;list-style-type: none;} a{margin-left: 20px; text-decoration: none; color: navy;} p{display: block;}</style>
    
    <ul>

        <li><a href="main.php">Acceuil</a></li>

        <li><a href="uncrypt.php">Voir les infos</a></li>
        
    </ul>
    </div>
</div> 

<div class="row  m-5">
    <div class="col-lg-6">
    <form method="post" enctype="multipart/form-data"  action="main.php">
        
<p>
    
    Message : <textarea name="texte" class="form-control">
        

    </textarea>


         </p>

         <p>
Votre image
         <input type="file" name="image" class="form-control">
         <br> uniquement les fichiers BMP
</p>

  <p class="forme-inline"><input type="submit" name="end" class="btn btn-success  w-3" value="Process" ></p>
           </form>
    
   </div>
</div> 


   <?php
}

 



?>
</body>
</html>