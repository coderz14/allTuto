Pour plus d'infos rdv sur http://sdz.tdct.org/sdz/dissimuler-un-texte-dans-une-image.html 

Happy Coding les Braves😊😊😊😊😎