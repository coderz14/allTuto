<?php

$lien = "weLoveCode.bmp";
$tampon = 0;
$message = "";
$i = 0; //variable qui va servir à compter le nombre d'octets déjà lus

$f_image = fopen($lien, 'rb'); // On ne modifie pas le fichier cette fois-ci, donc le mode r suffit.
fseek($f_image, 54); // On saute le header.
while(!feof($f_image)) // En théorie, on pourrait faire une boucle infinie que l'on ira « breaker » mais on ne va quand même pas tenter le diable, hein…
{ 
    $i++; //très important !

    $octet_image = fread($f_image, 1);
    $octet_image = ord($octet_image); // On lit la valeur du "charactère" lu.
    $bits_pf     = $octet_image%4;

    $tampon      = ($tampon << 2) | $bits_pf; // On rajoute ce qu'on a trouvé au tampon.

    if($i % 4 == 0) //c'est-à-dire quand on a lu 4 octets d'affilée
    {
        // Une fois qu'on a la valeur du caractère du message 
        
        if($tampon == 26)
        {
            // Fin du message
            echo $message;
            return;
        }
        

        $message .= chr($tampon); // Si l'on n'est pas arrivé à la fin du message, on ajoute le caractère trouvé et on réinitialise le tampon.
        $tampon = 0;
    }

}



?>