<?php


$idUser = 1;

$bd = new PDO("mysql:host=localhost;dbname=maBD","root","");




$data = file_get_contents('fronendimg.jpg') ; // ou fread(fopen('fronendimg.jpg', 'rb'), filesize('fronendimg.jpg'));

$img = base64_encode($data) ;


unset($data);
//On libere de la memoire ;
flush();



$update =  $bd->prepare("UPDATE tableImg SET img = :img WHERE id = :idUser");

$update->execute(array(':img'=>$img, ':idUser'=>$idUser));

unset($img);

$afficherImg = $bd->query("SELECT * FROM tableImg WHERE id=".$idUser."")->fetch(); 

echo "Bienvenu Mr <b>".$afficherImg['name']."</b>";

$image = "data:image/jpeg;base64,".$afficherImg['img']; //On convertie la chaine de caractere pour qu'il s'affiche en HTML



echo "<img src='".$image."' width='400' height='400'>";

?>