<?php
namespace MyApp;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;


class Chat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;

        $this->userObj = new \MyApp\user;
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
  


            $queryString = $conn->httpRequest->getUri()->getQuery();

        parse_str($queryString, $query);

        if($data = $this->userObj->getUserBySession($query['token']))

        {
            $this->data = $data ;
            $conn->data = $data ;

           $this->userObj->updateConnection($conn->resourceId, $data->userID);

            $this->clients->attach($conn);



        echo "New connection! ({$data->username})\n";
        }
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $numRecv = count($this->clients) - 1;
        echo $msg."\n".sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
            , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');

        $data = json_decode($msg, true);
      
       $sendTo = $this->userObj->userData($data['sendTo']);

        $send['sendTo'] = $sendTo->userID ;

        $send['by']     = $from->data->userID;

        $send['profilImage']     = $from->data->profilImage;

        $send['username']     = $from->data->username;



         $send['type']     = $data['type'];

          $send['data']     = $data['data'];


          $this->userObj->insertMessage($send['by'], $send['sendTo'], $send['data']);

        foreach ($this->clients as $client) {
            if ($from !== $client) {
                // The sender is not the receiver, send to each client connected

              
                    $client->send(json_encode($send));
              

                
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->clients->detach($conn);

        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}