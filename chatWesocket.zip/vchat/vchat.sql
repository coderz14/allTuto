-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 21 mai 2024 à 11:04
-- Version du serveur : 8.2.0
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `vchat`
--

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idExp` int NOT NULL,
  `idDest` int NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `idExp`, `idDest`, `message`) VALUES
(4, 1, 2, 'salut'),
(3, 2, 1, 'salut'),
(5, 1, 2, 'salut');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `username` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profilImage` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sessionID` varchar(55) NOT NULL,
  `connectionID` int NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`userID`, `username`, `name`, `email`, `password`, `profilImage`, `sessionID`, `connectionID`) VALUES
(1, 'terrios', 'ted', 'ted@gmail.com', '$2y$10$3DDaKCxEdYT64H4McgJfd.Bhv1CXtHjsjQH40Bd0KHrRbtfl9lY0q', 'defaultImage.png', 'i3vvt583vcd221dpd5fj59fpm5', 108),
(2, 'kamdem', 'Jean', 'jean@gmail.com', '$2y$10$3DDaKCxEdYT64H4McgJfd.Bhv1CXtHjsjQH40Bd0KHrRbtfl9lY0q', 'defaultImage.png', 'n58emrjf4qk6p09hh745vr9itb', 96);

-- --------------------------------------------------------

--
-- Structure de la table `vchat`
--

DROP TABLE IF EXISTS `vchat`;
CREATE TABLE IF NOT EXISTS `vchat` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `username` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profileImage` varchar(55) NOT NULL,
  `sessionID` varchar(55) NOT NULL,
  `connectionID` int NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `vchat`
--

INSERT INTO `vchat` (`userID`, `username`, `name`, `email`, `password`, `profileImage`, `sessionID`, `connectionID`) VALUES
(1, 'Yissibi', 'ted', 'ted@gmail.com', '$2y$10$MPpfujSz1pkqVARhJl2EIu7A7O//Ounee0crEEvkMgN37MeCnD.Gm', 'defaultImage.png', '0', 0),
(2, 'Kamdem', 'jean', 'Jean@gmail.com', '$2y$10$MPpfujSz1pkqVARhJl2EIu7A7O//Ounee0crEEvkMgN37MeCnD.Gm', 'defaultImage.png', '0', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
