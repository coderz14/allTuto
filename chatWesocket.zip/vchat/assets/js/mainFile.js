"use strict";

	alert('salut');
let callBtn = $('#callBtn');


let callBox = $('#callBox');


let answerBtn = $('#answerBtn');


let declineBtn = $('#declineBtn');


let pc;
let sendTo = callBtn.data('user');
let localStream;
const localVideo = document.querySelector("#localVideo");
const remoteVideo = document.querySelector("#remoteVideo");

const mediaConst = {
video:true
};


const options = {
	offerToReceiveVideo: 1,
};


function getConn()

{
	if(!pc)
	{
		pc = new RTCPeerConnection();
	}
}


async function getCam()

{

	if(!pc)
		{
		await	getConn();
		}


	let mediaStream;
	try{

		

		mediaStream = await navigator.mediaDevices.getUserMedia(mediaConst);

		localVideo.srcObject = mediaStream;

		localStream = mediaStream ;


				localStream.getTracks().forEach( track => pc.addTrack(track, localStream) 
);
	}
	catch(error)
	{
		alert(error);
	}
}



$('#callBtn').on('submit', () => {



	//getCam();

	alert('salut');
	send('is-client-ready', null, sendTo);

	return false ;
});



async function createOffer(sendTo)
{
	await sendIceCandidate(sendTo);
	await pc.createOffer(options);
	await pc.setLocalDescription(pc.localDescription);

	send('client-offer', pc.localDescription, sendTo);

	}



async function sendIceCandidate(sendTo)
{




	pc.onicecandidate = e => {
		if(e.candidate !== null)
		{

            
			send('client-candidate', e.candidate, sendTo);

		}
	}



	
}

conn.onopen = e =>{
	console.log('connected to websocket ');
};



conn.onmessage = async e =>{


};





function send(type, data, sendTo)
{
	conn.send(JSON.stringify({
		sendTo:sendTo,
		type:type,
		data:data
	}));
}