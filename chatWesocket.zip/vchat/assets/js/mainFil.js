"use strict";

		 
let callBtn = $('#callBtn');


let callBox = $('#callBox');


let answerBtn = $('#answerBtn');







let declineBtn = $('#declineBtn');





let pc;
let sendTo = callBtn.data('user');
let localStream;
const localVideo = document.querySelector("#localVideo");
const remoteVideo = document.querySelector("#remoteVideo");

const mediaConst = {
video:true
};


const options = {
	offerToReceiveVideo: 1,
};


function getConn()

{
	if(!pc)
	{
		pc = new RTCPeerConnection();
	}
}


async function getCam()

{

	if(!pc)
		{
		await	getConn();
		}


	let mediaStream;
	try{

		

		mediaStream = await navigator.mediaDevices.getUserMedia(mediaConst);

		localVideo.srcObject = mediaStream;

		localStream = mediaStream ;


				localStream.getTracks().forEach( track => pc.addTrack(track, localStream) 
);
	}
	catch(error)
	{
		alert(error);
	}
}



$('#callBtn').on('submit', function() {



	//getCam();

var message = $('#message').val();

let img = $('#img').attr('src');


 
		alert(error);


	$('#idrReceiver').append('<div class="chat-right  p-0 mt-2  col-10 ml-5" style="height:auto;"   ><p class="text-white mb-1" style="width:100%;word-wrap: break-word;text-align:right;" ><span class="p-2" style="height:auto;">'+message+'</span><img src="'+img+'" width="40" height="40" class="rounded-circle" class="ml-5"></p><p class="ml-5" style="text-align:right;"><small class="text-secondary">3mins ago</small></p></div>');

 

	send('is-client-ready', null, sendTo);

	return false ;
});



async function createOffer(sendTo)
{
	await sendIceCandidate(sendTo);
	await pc.createOffer(options);
	await pc.setLocalDescription(pc.localDescription);

	send('client-offer', pc.localDescription, sendTo);

	}



async function sendIceCandidate(sendTo)
{




	pc.onicecandidate = e => {
		if(e.candidate !== null)
		{

            
			send('client-candidate', e.candidate, sendTo);

		}
	}



	
}

conn.onopen = e =>{
	console.log('connected to websocket ');
};



conn.onmessage = async e =>{


let message = JSON.parse(e.data);
let by = message.by ;
let type = message.type ;

switch(type)
{
	case "is-client-ready":

//$('#idrReceiver').append('<div class="chat-left chat-first mb-2"><p class="bc-description mr-5"><img src="'+profileImage+'" width="40" height="40" class="rounded-circle"><span>'+data+' </span></p><small class="text-muted">3mins ago</small></div>');



	break;
}

};





function send(type, data, sendTo)
{
	conn.send(JSON.stringify({
		sendTo:sendTo,
		type:type,
		data:data
	}));
}