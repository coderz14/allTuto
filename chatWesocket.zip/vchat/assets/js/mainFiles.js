"use strict";

		 
let dest = $('#dest');

let sendTo = dest.data('user');

	


$('#callBtn').on('submit', function() {


 
var message = $('#message').val();

let img = $('#img').attr('src');


 
$('#idrReceiver').append('<div class="chat-right  p-0 mt-2  col-10 ml-5" style="height:auto;"   ><p class="text-white mb-1" style="width:100%;word-wrap: break-word;text-align:right;" ><span class="p-2" style="height:auto;">'+message+'</span><img src="'+img+'" width="40" height="40" class="rounded-circle" class="ml-5"></p><p class="ml-5" style="text-align:right;"><small class="text-secondary">3mins ago</small></p></div>');

 send('is-client-ready', message, sendTo);

return false ;
});








conn.onopen = e =>{
	console.log('connected to websocket ');
};



conn.onmessage = async e =>{
 

let message = JSON.parse(e.data);

let by = message.by ;

let dest = message.sendTo ;

let type = message.type ;

let profileImage = message.profilImage;

let data = message.data;

switch(type)
{
	case "is-client-ready":

 

let idrReceiver = $('#idrReceiver').data('user');




if(sendTo == by )

{
	$('#idrReceiver').append('<div class="chat-left chat-first mb-2"><p class="bc-description mr-5"><img src="assets/images/'+profileImage+'" width="40" height="40" class="rounded-circle"><span>'+data+' </span></p><small class="text-muted">3mins ago</small></div>');
}

 

	break;
}

};





function send(type, data, sendTo)
{
	conn.send(JSON.stringify({
		sendTo:sendTo,
		type:type,
		data:data
	}));
}