Salut les Coderz, je vous presente vchat. C'est un systeme simple de messagerie simple baser sur la discussion en temps
réel. A cet effet pas besoin de reactualiser la page apres un certain temps ou de mettre un minuteur sur des requetes
ajax afin de recuperer les derniers message. Les messages arrivent au destinataire  aussi instantement que le ferai un sms. 

***INSTALLATION***

- Decompressez le fichier 'chatWesocket.zip' a la racine de votre projet PHP (www ou htdocs) 

- Creer une base de données nommer "vchat" ensuite importer le fichier 'vchat.sql' dans cette derniere

- Ensuite demarrer le serveur websocket. Pour le faire acceder en ligne de commande au fichier 'bin' situer a la
racine de vchat. Vous ouvrez cmd ensuite vous tapez la commande "cd c:/wamp64/www/vchat/bin" ou la la commande "cd c:/wamp64/htdocs/vchat/bin". Ensuite demarrez le serveur avec la commande "php server.php"

- Ouvrez deux navigateurs differents avec le lien "localhost/vchat" connecter chacun des comptes pour effectuer les tests d'envoi de messages avec deux utilisateurs differents

-Selectionnez les destinataires dans chaque fenetres de chaque des deux navigateurs et je vous conseillerai de reduire 
la taille des navigateurs pour voir comment les messages arrivent instantanement

- Et amusez vous!


utilisateur 1 : ted@gmail.com , mot de passe: password 

utilisateur 2 : jean@gmail.com , mot de passe: password 