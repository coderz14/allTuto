<?php

session_start();

$_SESSION['name'] = 'Jerry';


$bd = new PDO("mysql:host=localhost;dbname=encrypt","root","");


?>

<!DOCTYPE html>
<html>
<head>
	<title>Bienvenue dans le cryptage</title>

<link rel="stylesheet" type="text/css" href="../public/css/modelcss/bootstrap.style.css">


</head>
<body>

		<p>
		<ul class="list-group d-flex flex-row">
			<li class="list-group-item"><a href="main.php">Acceuil</a></li>
			<li class="list-group-item"><a href="main.php?decryptMessage=true">Liste des messages</a></li>

		</ul>
		


	</p>

	<h2 class="mb-3 text-center mt-3">Tuto cryptage 

<?php

if(!isset($_POST['submit']) && !isset($_GET['decryptMessage'])  )
{

?>

page de cryptage</h2>
	<div class="row">

		<div class="col-lg-5 mt-5" style="margin: auto; ">
		<form method="post" action="main.php">
			
<p>Message<textarea name="message" class="form-control"></textarea></p>

<p class="form-inline">Mot de passe :<input type="password" name="password" class="form-control">  </p>

<p class="form-inline">
	Methode de cryptage: <select name="method" class="form-control">
		<option value="aes-256-cbc">aes-256-cbc</option>
	</select>
</p>

<p>
	
	<input type="submit" name="submit" class="btn btn-success">
</p>

		</form>
	</div> </div>
	<?php
}
elseif(isset($_POST['submit']))
{	

?>


page d'enregistrement de message crypter</h2>

<?php
if (strlen($_POST['message']) >= 3 ) {
	# code...

		$method = "aes-256-cbc"; // cipher method

	$message = $_POST['message'];

	$password = $_POST['password'];

	$Longueurvecteur = openssl_cipher_iv_length($method);


$strong = false ;

$vecteur = openssl_random_pseudo_bytes($Longueurvecteur);



	$encrypt = base64_encode(openssl_encrypt($message, $method, $password, 0,$vecteur))  ; //ON utlilise la fonction openssl_encrypt



	$update =  $bd->prepare("INSERT INTO messages (name,message,iv,dateExp) VALUES(:name, :message,:iv, :dateExp)");

$update->execute(array(':name'=>$_SESSION['name'], ':message'=>$encrypt,  ':dateExp'=> date('Y-m-d H:i:s'), ':iv'=> bin2hex($vecteur)));


$select = $bd->query("SELECT MAX(id) as id, message FROM messages");
 
$result= $select->fetch(PDO::FETCH_ASSOC);

 


 	$decrypt = openssl_decrypt(base64_decode($result['message']) , $method, $password,0,$vecteur);

	
if($decrypt)
{
	echo $result = '<p class=\'text-center\'>Le Message a ete crypter🔐🔐 : si vous voulez le decrypter cliquez : <a href="main.php?decryptMessage=true">ici</a> </p>';
}


}
else
{
	$message = 'message trop court';
}
	
	?>




<?php } 

elseif(isset($_GET['decryptMessage']) && $_GET['decryptMessage']=='true')
{

	$data = $bd->query("SELECT * FROM messages"); //on ouvre notre fichier en mode lecture seule

	
$concat = '';
	while ($result = $data->fetch()) {
		# code...

	 

		$name = $result['name'];

		$id = $result['id'];

		$date = date('d-m-Y H:i:s', strtotime($result['dateExp'])) ;

 

		$concat .="<tr class='form-inline'><td><input type='radio' class='form-control' name='id' value='".$id."'><b>Expediteur :</b>".$name."</td> <td><b>Expedier le :</b> ".$date."</td>

		 <td>mot de passe: <input type='text' name='password[]' class='form-control'>  </td></tr> ";

		

			}
?>
 

liste des message a decrypter</h5> 


<div class="row " >
	
	<div class="col-lg-6 mt-3" style="margin: auto;">
		


	


<form method="post" action="decrypt.php">
	
    <table>
    	

    <?php

echo $concat;

    ?>
 </table>
    <p class="form-inline">
	Methode de cryptage: <select name="method" class="form-control">
		<option value="aes-256-cbc">aes-256-cbc</option>
	</select>
</p>


<input type="submit" name="decrypt" class="btn btn-success">
   


    </form>

    </div>



</div>
<?php

}

	?>

</body>
</html>