<?php

session_start();

$_SESSION['name'] = 'Jerry';

?>

<!DOCTYPE html>
<html>
<head>
	<title>Bienvenue dans le cryptage</title>

<link rel="stylesheet" type="text/css" href="../public/css/modelcss/bootstrap.style.css">


</head>
<body>

	<h2 class="mb-3 text-center mt-3">Resultat décryptage : </h2>



	<p>
		<ul class="list-group d-flex flex-row">
			<li class="list-group-item"><a href="main.php">Acceuil</a></li>
			<li class="list-group-item"><a href="main.php?decryptMessage=true">Liste des messages</a></li>

		</ul>
		


	</p>

<?php


 if(isset($_POST['decrypt']) )
{

	$bd = new PDO("mysql:host=localhost;dbname=encrypt","root","");

		$method = "aes-256-cbc"; // cipher method

	$id = $_POST['id'];

	 

	$password = $_POST['password'][0];



	$Longueurvecteur = openssl_cipher_iv_length($method);


$strong = false ;

$vecteur = openssl_random_pseudo_bytes($Longueurvecteur);






$select = $bd->query("SELECT * FROM messages WHERE id=".$id." ");
 
$result= $select->fetch(PDO::FETCH_ASSOC); //On recupere le dernier message, le vecteur d'initialisation en base de donnees 

 $message = $result['message'];

 $decrypt = openssl_decrypt(base64_decode($message) , $method, $password,0,hex2bin($result['iv'])); //on converti le vecteur d'initialisation en binaire

 


 
	




	if($decrypt)
		{ 
	?>

<h4>Message decrypter avec succces😀😀: <span class="text-primary"><?php echo $decrypt; ?></span></h4>
	<?php } else{
		echo "Le mot de passe de decryptage est incorrect ☹☹☹ : Veuillez contacter l'expediteur pour avoir la cle de decriptage";
	}
}

	?>

</body>
</html>