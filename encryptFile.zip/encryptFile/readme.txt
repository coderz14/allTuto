
Salut les Coderz, aprés notre tuto sur la sécurité des fichiers voici une démo. Nous avons parler de
plusieurs méthode de sécurisation des fichiers. Nous allons faire une démo sur de la cryptographie des fichiers qui selon moi est l'un des moyens les plus sure pour proteger un fichier.  je vais vous expliquer notre code sur la cryptage de n'importe quel fichier . Allons y les gars !

Notre code est subdiviser en deux parties:

- une fonction de cryptage

- une fonction de décryptage

 
Tout d'abord nous definissons une constante nommer "FILE_ENCRYPTION_BLOCKS". Je vais vous expliquer son utilité plus tard

"fonction de cryptage""

Cette dernière prend en paramétre le fichier a crypter, le mot de passe, et le fichier finale crypter

Tout d'abord nous cryptons le mot de passe et nous le coupons sur une longueur de 16 caractères

Ensuite nous générons un mot de passe binaire unique a partir de 16 bits

Ensuite nous creeons le fichier finale à crypter en nous assurons qu'il ne contient rien

Dans ce fichier nous ecrivons notre mot de passe binaire unique

Maintenant nous nous assurons que nous pouvons ouvrir le fichier a crypter en mode binaire

Ensuite nous passons e fichier dans une boucle aui stipule aue tant aue le fichier n'est pas lu entiere,ent 
la boucle continu

Maintenant nous lisons le fichier ligne par ligne or en generale un fichier binaire contient une ligne de 16 blocks de 10000 bits chacun d'ou la constante "FILE_ENCRYPTION_BLOCKS"

maintenant nous cryptons chaque ligne binaire obtenu

nous rassurons d'abord de recuperer 16 bits de la ligne crypter pour la ligne suivante
et nous ecrivons les lignes obtenu dans le nouveau fichier ensuite nous reprenons le processus jusqu'a la fin e la lecture du fichier et on sort de la boucle. 

Ensuite si tout s'est bien passer on ferme le fichier et on libère de la mémoire.


""fonction de décryptage""

Cette dernière prend en paramétre le fichier  crypter, le mot de passe, et le fichier finale a décrypter.
Il faut noter que le processus en sensiblement le meme a la seule différence que nous allons ajouter à chaque ligne 1 bit 
et on allons utiliser la fonction "openssl_decript" sur chaque ligne


 Besoin d'aide rdv sur: facebook.com/profile.php?id=615563377536173
Pour des contacts et partenariat : sunasoft@suna-soft.com ou www.suna-soft.com